package com.thaiopensource.validate.picl;

interface Constraint {
  void activate(PatternManager pm);
}
